功能：
1.下载 GFW.Press 服务器上的 用户列表文件到本地，即 user.txt文件
2.修改 GFW.Press 服务器 root 用户密码

说明：
1.把本目录gfwpresstool考到 GFW.Press 的安装目录下，双击执行 exec.bat，根据提示操作即可。
2.下载的user.txt文件会放到data目录下
